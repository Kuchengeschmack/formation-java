
import java.util.*;

/**
 * 
 */
public class Livre extends Document {

    /**
     * Default constructor
     */
    public Livre() {
    }

    /**
     * 
     */
    public String genre;

    /**
     * 
     */
    public int nombrePages;

}