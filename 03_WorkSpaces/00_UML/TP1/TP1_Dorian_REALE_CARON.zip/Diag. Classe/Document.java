
import java.util.*;

/**
 * 
 */
public class Document {

    /**
     * Default constructor
     */
    public Document() {
    }

    /**
     * 
     */
    public int id;

    /**
     * 
     */
    public String code;

    /**
     * 
     */
    public String localisationSalle;

    /**
     * 
     */
    public String localisationRayon;

    /**
     * 
     */
    public boolean empruntPossible;

    /**
     * 
     */
    public String titre;

    /**
     * 
     */
    public String auteur;

    /**
     * natureAuteur est un attribut pouvant prendre les valeurs "écrivain", "groupe", "metteur en scène"
     */
    public String natureAuteur;

    /**
     * 
     */
    public int anneeSortie;

    /**
     * 
     */
    public FicheEmprunt 1..*;

}