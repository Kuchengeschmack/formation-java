
import java.util.*;

/**
 * 
 */
public class Employe {

    /**
     * Default constructor
     */
    public Employe() {
    }

    /**
     * @return
     */
    public Client ajouterClient() {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public Client supprimerClient() {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public Document ajouterDocument() {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public Document supprimerDocument() {
        // TODO implement here
        return null;
    }

    /**
     * 
     */
    public void reviserCategoriesEtConditions() {
        // TODO implement here
    }

}