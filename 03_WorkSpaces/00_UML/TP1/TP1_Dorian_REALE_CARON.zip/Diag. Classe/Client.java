
import java.util.*;

/**
 * 
 */
public class Client {

    /**
     * Default constructor
     */
    public Client() {
    }

    /**
     * 
     */
    public int id;

    /**
     * 
     */
    public String nom;

    /**
     * 
     */
    public String prénom;

    /**
     * 
     */
    public String adresse;

    /**
     * 
     */
    public boolean tarifReduit;

    /**
     * 
     */
    public boolean abonne;

    /**
     * 
     */
    public String justificatifTarifReduit;


    /**
     * 
     */
    public void mettreAJourJustificatif() {
        // TODO implement here
    }

    /**
     * @return
     */
    public String consulterStatEmpruntCategories() {
        // TODO implement here
        return "";
    }

    /**
     * @return
     */
    public String consulterStatEmpruntGenres() {
        // TODO implement here
        return "";
    }

    /**
     * 
     */
    public void consulterCatalogue() {
        // TODO implement here
    }

    /**
     * 
     */
    public void consulterEmprunts() {
        // TODO implement here
    }

    /**
     * @return
     */
    public String mettreAJourAdresse() {
        // TODO implement here
        return "";
    }

}