
import java.util.*;

/**
 * 
 */
public class CdAudio extends Document {

    /**
     * Default constructor
     */
    public CdAudio() {
    }

    /**
     * 
     */
    public String genreMusical;

    /**
     * 
     */
    public String classification;

}