
import java.util.*;

/**
 * La méthode calculerTarifEmprunt permet de déterminer la somme à verser lors de l'emprunt par le Client.
 * 
 * Elle prend en
 */
public class FicheEmprunt {

    /**
     * Default constructor
     */
    public FicheEmprunt() {
    }

    /**
     * Un document peut être emprunté plusieurs fois au cours de sa vie, et donc posséder plusieurs fiches d'emprunt distinctes, numérotées par l'attribut "id" de la classe "FicheEmprunt"
     */
    public int id;

    /**
     * 
     */
    public LocalDate dateDebutPret;

    /**
     * 
     */
    public Document documentEmprunte;

    /**
     * 
     */
    public LocalDate dateLimiteRestitution;

    /**
     * 
     */
    public double tarifEmprunt;

    /**
     * 
     */
    public Client 1;

    /**
     * 
     */
    public Document 1;

    /**
     * @param dateDebutPret 
     * @param dateLimiteRestitution 
     * @param client 
     * @return
     */
    public double calculerTarifEmprunt(LocalDate dateDebutPret, LocalDate dateLimiteRestitution, Client client) {
        // TODO implement here
        return 0.0d;
    }

    /**
     * @param client
     */
    public void calculerConditionsEmprunt(Client client) {
        // TODO implement here
    }

}