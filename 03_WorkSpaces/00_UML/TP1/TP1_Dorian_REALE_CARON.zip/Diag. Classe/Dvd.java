
import java.util.*;

/**
 * 
 */
public class Dvd extends Document {

    /**
     * Default constructor
     */
    public Dvd() {
    }

    /**
     * 
     */
    public String genre;

    /**
     * 
     */
    public LocalDate dureeEmission;

    /**
     * 
     */
    public String mentionLegaleDiffusion;

}